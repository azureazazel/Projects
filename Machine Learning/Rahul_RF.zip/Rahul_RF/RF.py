from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import os
import seaborn as sns # type: ignore
import pandas as pd

def load_images_from_folder(base_folder, size=(256, 256)):  # Set a smaller size if needed
    images = []
    labels = []
    for label in os.listdir(base_folder):
        label_folder = os.path.join(base_folder, label)
        for filename in os.listdir(label_folder):
            img_path = os.path.join(label_folder, filename)
            with Image.open(img_path) as img:
                img = img.convert('L')  # Convert to grayscale
                img = img.resize(size)  # Resize the image
                img_array = np.array(img)
                if img_array is not None:
                    images.append(img_array.flatten())
                    corrected_label = 1 if label == '0' else 0
                    labels.append(corrected_label)
    return np.array(images), np.array(labels)
X_train, y_train = load_images_from_folder(r'C:\Users\rahul\OneDrive\Documents\ML\music_genre\mfcc_stack\train')
X_val, y_val = load_images_from_folder(r'C:\Users\rahul\OneDrive\Documents\ML\music_genre\mfcc_stack\valid')

from sklearn.decomposition import PCA
pca = PCA(n_components=50)
X_train = pca.fit_transform(X_train)
X_val = pca.transform(X_val)

from sklearn.ensemble import RandomForestClassifier
rf_classifier = RandomForestClassifier(n_estimators=100, max_depth=30, random_state=42)
rf_classifier.fit(X_train, y_train)

from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score
y_pred = rf_classifier.predict(X_val)
print(classification_report(y_val, y_pred))
print("Accuracy:", accuracy_score(y_val, y_pred))
# Calculate precision and recall for each class
precision = precision_score(y_val, y_pred, average=None)  # average=None to get results for each class
recall = recall_score(y_val, y_pred, average=None)

# Now create the DataFrame
data = {
    'Class Label': ['Non-Prog Rock', 'Prog Rock'],  # Adjust these labels according to your classes
    'Precision': precision,
    'Recall': recall
}
metrics_df = pd.DataFrame(data)
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
sns.barplot(x='Class Label', y='Precision', data=metrics_df)
plt.title('Precision for Each Class')
plt.ylim(0, 1)  # Ensure that y-axis ranges from 0 to 1 for clarity

plt.subplot(1, 2, 2)
sns.barplot(x='Class Label', y='Recall', data=metrics_df)
plt.title('Recall for Each Class')
plt.ylim(0, 1)  # Ensure that y-axis ranges from 0 to 1 for clarity

plt.tight_layout()
plt.show()

# Plotting the confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_val, y_pred)

plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap='Blues', xticklabels=['Non-Prog Rock', 'Prog Rock'], yticklabels=['Non-Prog Rock', 'Prog Rock'])
plt.ylabel('Actual Label')
plt.xlabel('Predicted Label')
plt.title('Confusion Matrix')
plt.show()




